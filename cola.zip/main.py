from nome_do_trabalho import NomeDaClass

NomeDaClass()